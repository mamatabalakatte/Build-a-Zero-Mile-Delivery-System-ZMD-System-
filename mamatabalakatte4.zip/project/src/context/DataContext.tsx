import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Parcel, Route, Driver, DeliveryReport } from '../types';

interface DataContextType {
  parcels: Parcel[];
  routes: Route[];
  drivers: Driver[];
  addParcel: (parcel: Omit<Parcel, 'id'>) => void;
  updateParcel: (id: string, updates: Partial<Parcel>) => void;
  assignRoute: (routeId: string, driverId: string) => void;
  updateParcelStatus: (parcelId: string, status: Parcel['status'], notes?: string) => void;
  getReport: () => DeliveryReport;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

// Mock data
const mockParcels: Parcel[] = [
  {
    id: '1',
    trackingId: 'ZM001234567',
    vendorId: '1',
    customerName: 'Alice Johnson',
    customerPhone: '+1234567890',
    customerEmail: 'alice@example.com',
    address: '123 Main St, Downtown',
    city: 'New York',
    area: 'Manhattan',
    coordinates: { lat: 40.7589, lng: -73.9851 },
    size: 'medium',
    weight: 2.5,
    value: 150,
    status: 'out_for_delivery',
    assignedDriverId: '3',
    routeId: 'route1',
    uploadedAt: '2024-01-15T08:00:00Z',
  },
  {
    id: '2',
    trackingId: 'ZM001234568',
    vendorId: '1',
    customerName: 'Bob Smith',
    customerPhone: '+1234567891',
    customerEmail: 'bob@example.com',
    address: '456 Park Ave, Midtown',
    city: 'New York',
    area: 'Manhattan',
    coordinates: { lat: 40.7614, lng: -73.9776 },
    size: 'small',
    weight: 1.2,
    value: 75,
    status: 'delivered',
    assignedDriverId: '3',
    routeId: 'route1',
    uploadedAt: '2024-01-15T08:30:00Z',
    deliveredAt: '2024-01-15T14:30:00Z',
  },
];

const mockRoutes: Route[] = [
  {
    id: 'route1',
    name: 'Manhattan Route A',
    driverId: '3',
    parcels: ['1', '2'],
    status: 'in_progress',
    estimatedDistance: 15.5,
    estimatedTime: 120,
    createdAt: '2024-01-15T07:00:00Z',
    startedAt: '2024-01-15T09:00:00Z',
  },
];

const mockDrivers: Driver[] = [
  {
    id: '3',
    name: 'Mike Driver',
    email: 'mike@company.com',
    phone: '+1234567892',
    vehicleNumber: 'NYC-1234',
    licenseNumber: 'DL123456789',
    rating: 4.8,
    totalDeliveries: 156,
    successRate: 94.2,
    currentLocation: { lat: 40.7614, lng: -73.9776 },
    status: 'busy',
  },
];

export function DataProvider({ children }: { children: ReactNode }) {
  const [parcels, setParcels] = useState<Parcel[]>(mockParcels);
  const [routes, setRoutes] = useState<Route[]>(mockRoutes);
  const [drivers] = useState<Driver[]>(mockDrivers);

  const addParcel = (parcelData: Omit<Parcel, 'id'>) => {
    const newParcel: Parcel = {
      ...parcelData,
      id: Date.now().toString(),
    };
    setParcels(prev => [...prev, newParcel]);
  };

  const updateParcel = (id: string, updates: Partial<Parcel>) => {
    setParcels(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const assignRoute = (routeId: string, driverId: string) => {
    setRoutes(prev => prev.map(r => 
      r.id === routeId ? { ...r, driverId, status: 'assigned' as const } : r
    ));
  };

  const updateParcelStatus = (parcelId: string, status: Parcel['status'], notes?: string) => {
    setParcels(prev => prev.map(p => 
      p.id === parcelId 
        ? { 
            ...p, 
            status, 
            deliveryNotes: notes,
            deliveredAt: status === 'delivered' ? new Date().toISOString() : p.deliveredAt
          } 
        : p
    ));
  };

  const getReport = (): DeliveryReport => {
    const delivered = parcels.filter(p => p.status === 'delivered').length;
    const failed = parcels.filter(p => p.status === 'failed').length;
    const pending = parcels.filter(p => !['delivered', 'failed'].includes(p.status)).length;
    
    return {
      totalParcels: parcels.length,
      delivered,
      failed,
      pending,
      successRate: parcels.length > 0 ? (delivered / parcels.length) * 100 : 0,
      avgDeliveryTime: 89, // minutes
      topPerformingDrivers: drivers.slice(0, 3),
      failureReasons: [
        { reason: 'Customer not available', count: 5 },
        { reason: 'Wrong address', count: 3 },
        { reason: 'Package damaged', count: 2 },
      ],
    };
  };

  return (
    <DataContext.Provider value={{
      parcels,
      routes,
      drivers,
      addParcel,
      updateParcel,
      assignRoute,
      updateParcelStatus,
      getReport,
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}