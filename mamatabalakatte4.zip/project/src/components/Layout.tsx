import React from 'react';
import { useAuth } from '../context/AuthContext';
import { LogOut, User, Package, Truck, Shield, BarChart3, MapPin } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  title: string;
}

const roleIcons = {
  vendor: Package,
  warehouse_supervisor: MapPin,
  driver: Truck,
  customer: User,
  admin: Shield,
  analyst: BarChart3,
};

const roleColors = {
  vendor: 'bg-blue-500',
  warehouse_supervisor: 'bg-green-500',
  driver: 'bg-orange-500',
  customer: 'bg-purple-500',
  admin: 'bg-red-500',
  analyst: 'bg-indigo-500',
};

export function Layout({ children, title }: LayoutProps) {
  const { user, logout } = useAuth();
  
  if (!user) return null;

  const RoleIcon = roleIcons[user.role];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Package className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-xl font-bold text-gray-900">Zero Mile Delivery</h1>
              </div>
              <div className="hidden md:block w-px h-6 bg-gray-300" />
              <h2 className="hidden md:block text-lg font-medium text-gray-700">{title}</h2>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 ${roleColors[user.role]} rounded-full flex items-center justify-center`}>
                  <RoleIcon className="w-5 h-5 text-white" />
                </div>
                <div className="hidden sm:block">
                  <p className="text-sm font-medium text-gray-900">{user.name}</p>
                  <p className="text-xs text-gray-500 capitalize">{user.role.replace('_', ' ')}</p>
                </div>
              </div>
              <button
                onClick={logout}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
}