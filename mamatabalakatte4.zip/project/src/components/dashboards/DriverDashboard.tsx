import React, { useState } from 'react';
import { Layout } from '../Layout';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { Navigation, Package, Camera, CheckCircle, XCircle, Clock, MapPin } from 'lucide-react';

export function DriverDashboard() {
  const { parcels, routes, drivers, updateParcelStatus } = useData();
  const { user } = useAuth();
  const [selectedParcel, setSelectedParcel] = useState<string | null>(null);
  const [deliveryNotes, setDeliveryNotes] = useState('');

  // Mock driver data - in real app, this would be based on logged-in driver
  const currentDriver = drivers.find(d => d.id === '3') || drivers[0];
  const driverRoutes = routes.filter(r => r.driverId === currentDriver.id);
  const assignedParcels = parcels.filter(p => p.assignedDriverId === currentDriver.id);

  const todayStats = {
    assigned: assignedParcels.length,
    delivered: assignedParcels.filter(p => p.status === 'delivered').length,
    pending: assignedParcels.filter(p => p.status === 'out_for_delivery').length,
    failed: assignedParcels.filter(p => p.status === 'failed').length,
  };

  const handleStatusUpdate = (parcelId: string, status: 'delivered' | 'failed') => {
    updateParcelStatus(parcelId, status, deliveryNotes);
    setSelectedParcel(null);
    setDeliveryNotes('');
  };

  const simulatePhotoUpload = () => {
    // In real app, this would open camera or file picker
    alert('Photo upload simulation - In production, this would open camera/gallery');
  };

  return (
    <Layout title="Driver Portal">
      <div className="space-y-6">
        {/* Driver Profile Card */}
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center text-white text-xl font-bold">
              {currentDriver.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-gray-900">{currentDriver.name}</h2>
              <p className="text-gray-600">{currentDriver.vehicleNumber}</p>
              <div className="flex items-center space-x-4 mt-2">
                <span className="flex items-center space-x-1 text-sm text-gray-600">
                  <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                  <span>Online</span>
                </span>
                <span className="text-sm text-gray-600">
                  Rating: {currentDriver.rating}/5.0 ⭐
                </span>
                <span className="text-sm text-gray-600">
                  {currentDriver.totalDeliveries} deliveries
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Today's Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-xl shadow-sm p-4 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Assigned</p>
                <p className="text-2xl font-bold text-gray-900">{todayStats.assigned}</p>
              </div>
              <Package className="w-6 h-6 text-blue-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-4 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Delivered</p>
                <p className="text-2xl font-bold text-green-600">{todayStats.delivered}</p>
              </div>
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-4 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-orange-600">{todayStats.pending}</p>
              </div>
              <Clock className="w-6 h-6 text-orange-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-4 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Failed</p>
                <p className="text-2xl font-bold text-red-600">{todayStats.failed}</p>
              </div>
              <XCircle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>

        {/* Active Route */}
        {driverRoutes.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Today's Route</h3>
                <button className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  <Navigation className="w-4 h-4" />
                  <span>Start Navigation</span>
                </button>
              </div>
            </div>
            
            <div className="p-6">
              {driverRoutes.map(route => (
                <div key={route.id} className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-gray-900">{route.name}</h4>
                    <span className="text-sm text-gray-600">
                      {route.parcels.length} stops • {route.estimatedDistance} km • {route.estimatedTime} min
                    </span>
                  </div>
                  
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-blue-800 mb-2">Route Optimization Active</p>
                    <p className="text-xs text-blue-600">
                      Optimized route saves 15 minutes and 3.2 km compared to default routing
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Delivery List */}
        <div className="bg-white rounded-xl shadow-sm border">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Today's Deliveries</h3>
          </div>
          
          <div className="divide-y divide-gray-200">
            {assignedParcels.map((parcel, index) => (
              <div key={parcel.id} className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className="w-6 h-6 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center font-medium">
                        {index + 1}
                      </span>
                      <h4 className="font-medium text-gray-900">{parcel.customerName}</h4>
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        parcel.status === 'delivered' ? 'bg-green-100 text-green-800' :
                        parcel.status === 'failed' ? 'bg-red-100 text-red-800' :
                        parcel.status === 'out_for_delivery' ? 'bg-blue-100 text-blue-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {parcel.status.replace('_', ' ')}
                      </span>
                    </div>
                    
                    <div className="space-y-1 text-sm text-gray-600">
                      <p className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{parcel.address}</span>
                      </p>
                      <p>Phone: {parcel.customerPhone}</p>
                      <p>Tracking: {parcel.trackingId}</p>
                    </div>
                  </div>

                  <div className="flex flex-col space-y-2 ml-4">
                    {parcel.status === 'out_for_delivery' && (
                      <>
                        <button
                          onClick={() => setSelectedParcel(parcel.id)}
                          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm"
                        >
                          Mark Delivered
                        </button>
                        <button
                          onClick={() => setSelectedParcel(parcel.id)}
                          className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors text-sm"
                        >
                          Mark Failed
                        </button>
                      </>
                    )}
                    
                    {parcel.status === 'delivered' && (
                      <span className="text-green-600 text-sm font-medium">✓ Completed</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Update Status Modal */}
        {selectedParcel && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl p-6 w-full max-w-md">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Update Delivery Status</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Delivery Notes
                  </label>
                  <textarea
                    value={deliveryNotes}
                    onChange={(e) => setDeliveryNotes(e.target.value)}
                    placeholder="Add any delivery notes..."
                    className="w-full p-3 border border-gray-300 rounded-lg"
                    rows={3}
                  />
                </div>

                <button
                  onClick={simulatePhotoUpload}
                  className="w-full flex items-center justify-center space-x-2 bg-gray-100 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <Camera className="w-5 h-5" />
                  <span>Upload Delivery Photo</span>
                </button>

                <div className="flex space-x-3">
                  <button
                    onClick={() => handleStatusUpdate(selectedParcel, 'delivered')}
                    className="flex-1 bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors"
                  >
                    Mark Delivered
                  </button>
                  <button
                    onClick={() => handleStatusUpdate(selectedParcel, 'failed')}
                    className="flex-1 bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 transition-colors"
                  >
                    Mark Failed
                  </button>
                </div>

                <button
                  onClick={() => setSelectedParcel(null)}
                  className="w-full text-gray-600 hover:text-gray-800 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}