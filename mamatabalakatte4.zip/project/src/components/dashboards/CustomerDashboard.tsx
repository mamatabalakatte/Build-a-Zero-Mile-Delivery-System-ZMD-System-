import React, { useState } from 'react';
import { Layout } from '../Layout';
import { useData } from '../../context/DataContext';
import { Search, Package, MapPin, Clock, CheckCircle, Bell } from 'lucide-react';

export function CustomerDashboard() {
  const { parcels } = useData();
  const [trackingId, setTrackingId] = useState('');
  const [searchResult, setSearchResult] = useState<any>(null);

  const handleTrackParcel = () => {
    const parcel = parcels.find(p => p.trackingId === trackingId);
    setSearchResult(parcel || 'not_found');
  };

  const statusSteps = [
    { key: 'uploaded', label: 'Order Received', icon: Package },
    { key: 'sorted', label: 'Sorted', icon: Package },
    { key: 'assigned', label: 'Assigned to Driver', icon: MapPin },
    { key: 'out_for_delivery', label: 'Out for Delivery', icon: Clock },
    { key: 'delivered', label: 'Delivered', icon: CheckCircle },
  ];

  const getStatusIndex = (status: string) => {
    return statusSteps.findIndex(step => step.key === status);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <Layout title="Track Your Parcel">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Hero Section */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Track Your Delivery</h1>
          <p className="text-lg text-gray-600">Enter your tracking ID to see real-time updates</p>
        </div>

        {/* Tracking Search */}
        <div className="bg-white rounded-2xl shadow-sm border p-8">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <input
                type="text"
                value={trackingId}
                onChange={(e) => setTrackingId(e.target.value)}
                placeholder="Enter your tracking ID (e.g., ZM001234567)"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
              />
            </div>
            <button
              onClick={handleTrackParcel}
              className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
            >
              <Search className="w-5 h-5" />
              <span>Track Parcel</span>
            </button>
          </div>
        </div>

        {/* Search Results */}
        {searchResult === 'not_found' && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <Search className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-red-900">Parcel Not Found</h3>
                <p className="text-red-700">Please check your tracking ID and try again.</p>
              </div>
            </div>
          </div>
        )}

        {searchResult && searchResult !== 'not_found' && (
          <div className="space-y-6">
            {/* Parcel Info Card */}
            <div className="bg-white rounded-2xl shadow-sm border p-8">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">
                    Tracking ID: {searchResult.trackingId}
                  </h2>
                  <p className="text-gray-600">To: {searchResult.customerName}</p>
                  <p className="text-gray-600">{searchResult.address}</p>
                </div>
                <div className="text-right">
                  <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${
                    searchResult.status === 'delivered' ? 'bg-green-100 text-green-800' :
                    searchResult.status === 'out_for_delivery' ? 'bg-blue-100 text-blue-800' :
                    searchResult.status === 'failed' ? 'bg-red-100 text-red-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {searchResult.status.replace('_', ' ').toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Status Timeline */}
              <div className="relative">
                <div className="flex items-center justify-between">
                  {statusSteps.map((step, index) => {
                    const StepIcon = step.icon;
                    const currentIndex = getStatusIndex(searchResult.status);
                    const isCompleted = index <= currentIndex;
                    const isCurrent = index === currentIndex;

                    return (
                      <div key={step.key} className="flex flex-col items-center relative">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 ${
                          isCompleted 
                            ? 'bg-blue-600 border-blue-600 text-white' 
                            : 'bg-white border-gray-300 text-gray-400'
                        } ${isCurrent ? 'ring-4 ring-blue-100' : ''}`}>
                          <StepIcon className="w-6 h-6" />
                        </div>
                        <div className="mt-2 text-center">
                          <p className={`text-xs font-medium ${
                            isCompleted ? 'text-blue-600' : 'text-gray-500'
                          }`}>
                            {step.label}
                          </p>
                        </div>
                        
                        {index < statusSteps.length - 1 && (
                          <div className={`absolute top-6 left-6 w-16 h-0.5 ${
                            index < currentIndex ? 'bg-blue-600' : 'bg-gray-300'
                          }`} style={{ zIndex: -1 }} />
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Delivery Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm border p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Parcel Details</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Size:</span>
                    <span className="font-medium capitalize">{searchResult.size}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Weight:</span>
                    <span className="font-medium">{searchResult.weight} kg</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Value:</span>
                    <span className="font-medium">${searchResult.value}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Order Date:</span>
                    <span className="font-medium">{formatDate(searchResult.uploadedAt)}</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Delivery Info</h3>
                <div className="space-y-3">
                  {searchResult.status === 'delivered' && searchResult.deliveredAt && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Delivered:</span>
                      <span className="font-medium text-green-600">
                        {formatDate(searchResult.deliveredAt)}
                      </span>
                    </div>
                  )}
                  
                  {searchResult.status === 'out_for_delivery' && (
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <Bell className="w-5 h-5 text-blue-600" />
                        <span className="text-blue-800 font-medium">Out for Delivery</span>
                      </div>
                      <p className="text-blue-700 text-sm mt-1">
                        Your parcel is on the way! Expected delivery today.
                      </p>
                    </div>
                  )}

                  {searchResult.status === 'failed' && (
                    <div className="bg-red-50 p-4 rounded-lg">
                      <p className="text-red-800 font-medium">Delivery Failed</p>
                      <p className="text-red-700 text-sm mt-1">
                        {searchResult.failureReason || 'Please contact customer service'}
                      </p>
                    </div>
                  )}

                  {searchResult.deliveryNotes && (
                    <div>
                      <span className="text-gray-600">Notes:</span>
                      <p className="font-medium mt-1">{searchResult.deliveryNotes}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Live Map Placeholder */}
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Live Tracking</h3>
              <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600">Interactive map would be shown here</p>
                  <p className="text-sm text-gray-500">Real-time driver location & route</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Quick Track Options */}
        {!searchResult && (
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Try Demo Tracking IDs</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {parcels.slice(0, 4).map((parcel) => (
                <button
                  key={parcel.id}
                  onClick={() => setTrackingId(parcel.trackingId)}
                  className="text-left p-3 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors"
                >
                  <p className="font-medium text-blue-600">{parcel.trackingId}</p>
                  <p className="text-sm text-gray-600 capitalize">{parcel.status.replace('_', ' ')}</p>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}