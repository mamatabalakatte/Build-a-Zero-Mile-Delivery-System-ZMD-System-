import React from 'react';
import { Layout } from '../Layout';
import { useData } from '../../context/DataContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { Download, TrendingUp, TrendingDown, Package, Clock, Users, AlertTriangle } from 'lucide-react';

export function AnalystDashboard() {
  const { getReport, parcels, drivers } = useData();
  const report = getReport();

  // Mock data for charts
  const deliveryTrendData = [
    { date: '2024-01-08', delivered: 45, failed: 5 },
    { date: '2024-01-09', delivered: 52, failed: 3 },
    { date: '2024-01-10', delivered: 49, failed: 7 },
    { date: '2024-01-11', delivered: 63, failed: 4 },
    { date: '2024-01-12', delivered: 58, failed: 6 },
    { date: '2024-01-13', delivered: 67, failed: 3 },
    { date: '2024-01-14', delivered: 71, failed: 5 },
  ];

  const areaDistributionData = [
    { name: 'Manhattan', value: 45, color: '#3B82F6' },
    { name: 'Brooklyn', value: 30, color: '#10B981' },
    { name: 'Queens', value: 20, color: '#F59E0B' },
    { name: 'Others', value: 5, color: '#EF4444' },
  ];

  const timeSlotData = [
    { timeSlot: '9-11 AM', deliveries: 25 },
    { timeSlot: '11-1 PM', deliveries: 45 },
    { timeSlot: '1-3 PM', deliveries: 38 },
    { timeSlot: '3-5 PM', deliveries: 52 },
    { timeSlot: '5-7 PM', deliveries: 33 },
  ];

  const handleDownloadReport = (type: string) => {
    // In a real app, this would generate and download actual reports
    alert(`${type} report download started - This would generate a real file in production`);
  };

  return (
    <Layout title="Analytics & Reports">
      <div className="space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm p-6 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Success Rate</p>
                <p className="text-3xl font-bold text-green-600">{report.successRate.toFixed(1)}%</p>
                <div className="flex items-center space-x-1 mt-1">
                  <TrendingUp className="w-4 h-4 text-green-500" />
                  <span className="text-xs text-green-600">+2.3% vs last week</span>
                </div>
              </div>
              <Package className="w-8 h-8 text-green-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Delivery Time</p>
                <p className="text-3xl font-bold text-blue-600">{report.avgDeliveryTime}min</p>
                <div className="flex items-center space-x-1 mt-1">
                  <TrendingDown className="w-4 h-4 text-green-500" />
                  <span className="text-xs text-green-600">-5 min vs last week</span>
                </div>
              </div>
              <Clock className="w-8 h-8 text-blue-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Deliveries</p>
                <p className="text-3xl font-bold text-purple-600">{report.delivered}</p>
                <div className="flex items-center space-x-1 mt-1">
                  <TrendingUp className="w-4 h-4 text-green-500" />
                  <span className="text-xs text-green-600">+12% vs last week</span>
                </div>
              </div>
              <Users className="w-8 h-8 text-purple-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Failed Deliveries</p>
                <p className="text-3xl font-bold text-red-600">{report.failed}</p>
                <div className="flex items-center space-x-1 mt-1">
                  <TrendingDown className="w-4 h-4 text-green-500" />
                  <span className="text-xs text-green-600">-8% vs last week</span>
                </div>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
          </div>
        </div>

        {/* Download Reports */}
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Export Reports</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => handleDownloadReport('Daily Summary')}
              className="flex items-center justify-center space-x-2 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Download className="w-5 h-5" />
              <span>Daily Summary</span>
            </button>
            <button
              onClick={() => handleDownloadReport('Driver Performance')}
              className="flex items-center justify-center space-x-2 bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors"
            >
              <Download className="w-5 h-5" />
              <span>Driver Performance</span>
            </button>
            <button
              onClick={() => handleDownloadReport('Failure Analysis')}
              className="flex items-center justify-center space-x-2 bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 transition-colors"
            >
              <Download className="w-5 h-5" />
              <span>Failure Analysis</span>
            </button>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Delivery Trends */}
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Delivery Trends (Last 7 Days)</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={deliveryTrendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="delivered" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="failed" stroke="#EF4444" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Area Distribution */}
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Delivery Distribution by Area</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={areaDistributionData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {areaDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Time Slot Analysis */}
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Deliveries by Time Slot</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={timeSlotData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="timeSlot" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="deliveries" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Driver Performance */}
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performing Drivers</h3>
            <div className="space-y-4">
              {report.topPerformingDrivers.map((driver, index) => (
                <div key={driver.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{driver.name}</p>
                      <p className="text-sm text-gray-600">{driver.vehicleNumber}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">{driver.successRate}%</p>
                    <p className="text-sm text-gray-600">{driver.totalDeliveries} deliveries</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Failure Analysis */}
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Failure Reasons Analysis</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {report.failureReasons.map((reason, index) => (
              <div key={index} className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-medium text-gray-900">{reason.reason}</p>
                  <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-sm font-medium">
                    {reason.count}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-red-600 h-2 rounded-full" 
                    style={{ width: `${(reason.count / Math.max(...report.failureReasons.map(r => r.count))) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}