import React, { useState } from 'react';
import { Layout } from '../Layout';
import { useData } from '../../context/DataContext';
import { Package, MapPin, Users, Truck, Filter, Search } from 'lucide-react';

export function WarehouseDashboard() {
  const { parcels, routes, drivers, assignRoute } = useData();
  const [selectedArea, setSelectedArea] = useState('all');
  const [selectedSize, setSelectedSize] = useState('all');

  const filteredParcels = parcels.filter(p => {
    const areaMatch = selectedArea === 'all' || p.area === selectedArea;
    const sizeMatch = selectedSize === 'all' || p.size === selectedSize;
    return areaMatch && sizeMatch;
  });

  const groupedByArea = filteredParcels.reduce((acc, parcel) => {
    if (!acc[parcel.area]) acc[parcel.area] = [];
    acc[parcel.area].push(parcel);
    return acc;
  }, {} as Record<string, typeof parcels>);

  const stats = {
    totalParcels: parcels.length,
    sortedParcels: parcels.filter(p => p.status === 'sorted').length,
    assignedRoutes: routes.filter(r => r.driverId).length,
    availableDrivers: drivers.filter(d => d.status === 'available').length,
  };

  const handleAssignDriver = (routeId: string, driverId: string) => {
    assignRoute(routeId, driverId);
  };

  return (
    <Layout title="Warehouse Operations">
      <div className="space-y-6">
        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm p-6 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Parcels</p>
                <p className="text-3xl font-bold text-gray-900">{stats.totalParcels}</p>
              </div>
              <Package className="w-8 h-8 text-blue-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Sorted Parcels</p>
                <p className="text-3xl font-bold text-green-600">{stats.sortedParcels}</p>
              </div>
              <Filter className="w-8 h-8 text-green-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Routes</p>
                <p className="text-3xl font-bold text-purple-600">{stats.assignedRoutes}</p>
              </div>
              <MapPin className="w-8 h-8 text-purple-600" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Available Drivers</p>
                <p className="text-3xl font-bold text-orange-600">{stats.availableDrivers}</p>
              </div>
              <Users className="w-8 h-8 text-orange-600" />
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm p-6 border">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Area</label>
              <select
                value={selectedArea}
                onChange={(e) => setSelectedArea(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Areas</option>
                <option value="Manhattan">Manhattan</option>
                <option value="Brooklyn">Brooklyn</option>
                <option value="Queens">Queens</option>
              </select>
            </div>

            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Size</label>
              <select
                value={selectedSize}
                onChange={(e) => setSelectedSize(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Sizes</option>
                <option value="small">Small</option>
                <option value="medium">Medium</option>
                <option value="large">Large</option>
              </select>
            </div>
          </div>
        </div>

        {/* Parcel Groups by Area */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {Object.entries(groupedByArea).map(([area, areaParcels]) => (
            <div key={area} className="bg-white rounded-xl shadow-sm border">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">{area}</h3>
                  <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                    {areaParcels.length} parcels
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <div className="space-y-3">
                  {areaParcels.slice(0, 5).map((parcel) => (
                    <div key={parcel.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="text-sm font-medium text-gray-900">{parcel.trackingId}</p>
                        <p className="text-xs text-gray-500">{parcel.customerName}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`w-3 h-3 rounded-full ${
                          parcel.size === 'small' ? 'bg-green-400' :
                          parcel.size === 'medium' ? 'bg-yellow-400' : 'bg-red-400'
                        }`}></span>
                        <span className="text-xs text-gray-500 capitalize">{parcel.size}</span>
                      </div>
                    </div>
                  ))}
                  
                  {areaParcels.length > 5 && (
                    <p className="text-sm text-gray-500 text-center py-2">
                      +{areaParcels.length - 5} more parcels
                    </p>
                  )}
                </div>

                <button className="w-full mt-4 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2">
                  <Truck className="w-4 h-4" />
                  <span>Create Route</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Active Routes */}
        <div className="bg-white rounded-xl shadow-sm border">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Active Routes</h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {routes.map((route) => (
                <div key={route.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-gray-900">{route.name}</h4>
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      route.status === 'completed' ? 'bg-green-100 text-green-800' :
                      route.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                      route.status === 'assigned' ? 'bg-purple-100 text-purple-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {route.status.replace('_', ' ')}
                    </span>
                  </div>
                  
                  <div className="space-y-2 text-sm text-gray-600">
                    <p>Parcels: {route.parcels.length}</p>
                    <p>Distance: {route.estimatedDistance} km</p>
                    <p>Est. Time: {route.estimatedTime} min</p>
                  </div>

                  {!route.driverId && (
                    <div className="mt-3">
                      <select
                        onChange={(e) => e.target.value && handleAssignDriver(route.id, e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded text-sm"
                        defaultValue=""
                      >
                        <option value="">Assign Driver</option>
                        {drivers.filter(d => d.status === 'available').map(driver => (
                          <option key={driver.id} value={driver.id}>{driver.name}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  {route.driverId && (
                    <div className="mt-3 p-2 bg-green-50 rounded text-sm">
                      <p className="text-green-800">
                        Assigned to: {drivers.find(d => d.id === route.driverId)?.name}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}