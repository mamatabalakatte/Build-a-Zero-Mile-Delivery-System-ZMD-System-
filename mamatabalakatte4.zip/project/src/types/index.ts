export interface User {
  id: string;
  name: string;
  email: string;
  role: 'vendor' | 'warehouse_supervisor' | 'driver' | 'customer' | 'admin' | 'analyst';
  avatar?: string;
}

export interface Parcel {
  id: string;
  trackingId: string;
  vendorId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  address: string;
  city: string;
  area: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  size: 'small' | 'medium' | 'large';
  weight: number;
  value: number;
  status: 'uploaded' | 'sorted' | 'assigned' | 'out_for_delivery' | 'delivered' | 'failed' | 'returned';
  assignedDriverId?: string;
  routeId?: string;
  uploadedAt: string;
  deliveredAt?: string;
  deliveryPhoto?: string;
  deliveryNotes?: string;
  failureReason?: string;
}

export interface Route {
  id: string;
  name: string;
  driverId?: string;
  parcels: string[];
  status: 'created' | 'assigned' | 'in_progress' | 'completed';
  estimatedDistance: number;
  estimatedTime: number;
  actualDistance?: number;
  actualTime?: number;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
}

export interface Driver {
  id: string;
  name: string;
  email: string;
  phone: string;
  vehicleNumber: string;
  licenseNumber: string;
  rating: number;
  totalDeliveries: number;
  successRate: number;
  currentLocation?: {
    lat: number;
    lng: number;
  };
  status: 'available' | 'busy' | 'offline';
}

export interface DeliveryReport {
  totalParcels: number;
  delivered: number;
  failed: number;
  pending: number;
  successRate: number;
  avgDeliveryTime: number;
  topPerformingDrivers: Driver[];
  failureReasons: { reason: string; count: number }[];
}