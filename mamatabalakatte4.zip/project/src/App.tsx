import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { LoginForm } from './components/LoginForm';
import { VendorDashboard } from './components/dashboards/VendorDashboard';
import { WarehouseDashboard } from './components/dashboards/WarehouseDashboard';
import { DriverDashboard } from './components/dashboards/DriverDashboard';
import { CustomerDashboard } from './components/dashboards/CustomerDashboard';
import { AdminDashboard } from './components/dashboards/AdminDashboard';
import { AnalystDashboard } from './components/dashboards/AnalystDashboard';

function AppContent() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginForm />;
  }

  const getDashboard = () => {
    switch (user.role) {
      case 'vendor':
        return <VendorDashboard />;
      case 'warehouse_supervisor':
        return <WarehouseDashboard />;
      case 'driver':
        return <DriverDashboard />;
      case 'customer':
        return <CustomerDashboard />;
      case 'admin':
        return <AdminDashboard />;
      case 'analyst':
        return <AnalystDashboard />;
      default:
        return <VendorDashboard />;
    }
  };

  return getDashboard();
}

function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <Router>
          <Routes>
            <Route path="/" element={<AppContent />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Router>
      </DataProvider>
    </AuthProvider>
  );
}

export default App;